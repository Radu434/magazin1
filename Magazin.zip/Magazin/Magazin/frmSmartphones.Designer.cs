﻿namespace Magazin
{
    partial class frmSmartphones
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.pnlNav = new System.Windows.Forms.Panel();
            this.pnlScroll = new System.Windows.Forms.Panel();
            this.btnWearables = new System.Windows.Forms.Button();
            this.btnFoto = new System.Windows.Forms.Button();
            this.btnConsole = new System.Windows.Forms.Button();
            this.btnAudio = new System.Windows.Forms.Button();
            this.btnElectrocasnice = new System.Windows.Forms.Button();
            this.btnDesktop = new System.Windows.Forms.Button();
            this.btnLaptop = new System.Windows.Forms.Button();
            this.btnTelevizoare = new System.Windows.Forms.Button();
            this.btnSmartphone = new System.Windows.Forms.Button();
            this.lblCategorii = new System.Windows.Forms.Label();
            this.pnlMain = new System.Windows.Forms.Panel();
            this.pnlTopBar = new System.Windows.Forms.Panel();
            this.btnCos = new System.Windows.Forms.Button();
            this.pnlNav.SuspendLayout();
            this.pnlScroll.SuspendLayout();
            this.pnlMain.SuspendLayout();
            this.pnlTopBar.SuspendLayout();
            this.SuspendLayout();
            // 
            // pnlNav
            // 
            this.pnlNav.Controls.Add(this.pnlScroll);
            this.pnlNav.Controls.Add(this.lblCategorii);
            this.pnlNav.Dock = System.Windows.Forms.DockStyle.Left;
            this.pnlNav.Location = new System.Drawing.Point(0, 0);
            this.pnlNav.Name = "pnlNav";
            this.pnlNav.Size = new System.Drawing.Size(207, 810);
            this.pnlNav.TabIndex = 0;
            // 
            // pnlScroll
            // 
            this.pnlScroll.AutoScroll = true;
            this.pnlScroll.AutoScrollMargin = new System.Drawing.Size(0, 50);
            this.pnlScroll.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(79)))), ((int)(((byte)(93)))), ((int)(((byte)(117)))));
            this.pnlScroll.Controls.Add(this.btnWearables);
            this.pnlScroll.Controls.Add(this.btnFoto);
            this.pnlScroll.Controls.Add(this.btnConsole);
            this.pnlScroll.Controls.Add(this.btnAudio);
            this.pnlScroll.Controls.Add(this.btnElectrocasnice);
            this.pnlScroll.Controls.Add(this.btnDesktop);
            this.pnlScroll.Controls.Add(this.btnLaptop);
            this.pnlScroll.Controls.Add(this.btnTelevizoare);
            this.pnlScroll.Controls.Add(this.btnSmartphone);
            this.pnlScroll.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pnlScroll.Location = new System.Drawing.Point(0, 63);
            this.pnlScroll.Name = "pnlScroll";
            this.pnlScroll.Size = new System.Drawing.Size(207, 747);
            this.pnlScroll.TabIndex = 0;
            // 
            // btnWearables
            // 
            this.btnWearables.Dock = System.Windows.Forms.DockStyle.Top;
            this.btnWearables.FlatAppearance.BorderSize = 0;
            this.btnWearables.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnWearables.Font = new System.Drawing.Font("Lucida Sans Typewriter", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnWearables.ForeColor = System.Drawing.Color.White;
            this.btnWearables.Location = new System.Drawing.Point(0, 480);
            this.btnWearables.Margin = new System.Windows.Forms.Padding(0);
            this.btnWearables.Name = "btnWearables";
            this.btnWearables.Padding = new System.Windows.Forms.Padding(0, 10, 0, 0);
            this.btnWearables.Size = new System.Drawing.Size(207, 60);
            this.btnWearables.TabIndex = 11;
            this.btnWearables.Text = "Wearables";
            this.btnWearables.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnWearables.UseVisualStyleBackColor = true;
            // 
            // btnFoto
            // 
            this.btnFoto.Dock = System.Windows.Forms.DockStyle.Top;
            this.btnFoto.FlatAppearance.BorderSize = 0;
            this.btnFoto.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnFoto.Font = new System.Drawing.Font("Lucida Sans Typewriter", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnFoto.ForeColor = System.Drawing.Color.White;
            this.btnFoto.Location = new System.Drawing.Point(0, 420);
            this.btnFoto.Margin = new System.Windows.Forms.Padding(0);
            this.btnFoto.Name = "btnFoto";
            this.btnFoto.Padding = new System.Windows.Forms.Padding(0, 10, 0, 0);
            this.btnFoto.Size = new System.Drawing.Size(207, 60);
            this.btnFoto.TabIndex = 10;
            this.btnFoto.Text = "Foto";
            this.btnFoto.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnFoto.UseVisualStyleBackColor = true;
            // 
            // btnConsole
            // 
            this.btnConsole.Dock = System.Windows.Forms.DockStyle.Top;
            this.btnConsole.FlatAppearance.BorderSize = 0;
            this.btnConsole.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnConsole.Font = new System.Drawing.Font("Lucida Sans Typewriter", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnConsole.ForeColor = System.Drawing.Color.White;
            this.btnConsole.Location = new System.Drawing.Point(0, 360);
            this.btnConsole.Margin = new System.Windows.Forms.Padding(0);
            this.btnConsole.Name = "btnConsole";
            this.btnConsole.Padding = new System.Windows.Forms.Padding(0, 10, 0, 0);
            this.btnConsole.Size = new System.Drawing.Size(207, 60);
            this.btnConsole.TabIndex = 9;
            this.btnConsole.Text = "Console Jocuri";
            this.btnConsole.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnConsole.UseVisualStyleBackColor = true;
            // 
            // btnAudio
            // 
            this.btnAudio.Dock = System.Windows.Forms.DockStyle.Top;
            this.btnAudio.FlatAppearance.BorderSize = 0;
            this.btnAudio.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnAudio.Font = new System.Drawing.Font("Lucida Sans Typewriter", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnAudio.ForeColor = System.Drawing.Color.White;
            this.btnAudio.Location = new System.Drawing.Point(0, 300);
            this.btnAudio.Margin = new System.Windows.Forms.Padding(0);
            this.btnAudio.Name = "btnAudio";
            this.btnAudio.Padding = new System.Windows.Forms.Padding(0, 10, 0, 0);
            this.btnAudio.Size = new System.Drawing.Size(207, 60);
            this.btnAudio.TabIndex = 8;
            this.btnAudio.Text = "Audio";
            this.btnAudio.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnAudio.UseVisualStyleBackColor = true;
            // 
            // btnElectrocasnice
            // 
            this.btnElectrocasnice.Dock = System.Windows.Forms.DockStyle.Top;
            this.btnElectrocasnice.FlatAppearance.BorderSize = 0;
            this.btnElectrocasnice.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnElectrocasnice.Font = new System.Drawing.Font("Lucida Sans Typewriter", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnElectrocasnice.ForeColor = System.Drawing.Color.White;
            this.btnElectrocasnice.Location = new System.Drawing.Point(0, 240);
            this.btnElectrocasnice.Margin = new System.Windows.Forms.Padding(0);
            this.btnElectrocasnice.Name = "btnElectrocasnice";
            this.btnElectrocasnice.Padding = new System.Windows.Forms.Padding(0, 10, 0, 0);
            this.btnElectrocasnice.Size = new System.Drawing.Size(207, 60);
            this.btnElectrocasnice.TabIndex = 4;
            this.btnElectrocasnice.Text = "Electrocasnice";
            this.btnElectrocasnice.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnElectrocasnice.UseVisualStyleBackColor = true;
            // 
            // btnDesktop
            // 
            this.btnDesktop.Dock = System.Windows.Forms.DockStyle.Top;
            this.btnDesktop.FlatAppearance.BorderSize = 0;
            this.btnDesktop.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnDesktop.Font = new System.Drawing.Font("Lucida Sans Typewriter", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnDesktop.ForeColor = System.Drawing.Color.White;
            this.btnDesktop.Location = new System.Drawing.Point(0, 180);
            this.btnDesktop.Margin = new System.Windows.Forms.Padding(0);
            this.btnDesktop.Name = "btnDesktop";
            this.btnDesktop.Padding = new System.Windows.Forms.Padding(0, 10, 0, 0);
            this.btnDesktop.Size = new System.Drawing.Size(207, 60);
            this.btnDesktop.TabIndex = 3;
            this.btnDesktop.Text = "Desktop";
            this.btnDesktop.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnDesktop.UseVisualStyleBackColor = true;
            // 
            // btnLaptop
            // 
            this.btnLaptop.Dock = System.Windows.Forms.DockStyle.Top;
            this.btnLaptop.FlatAppearance.BorderSize = 0;
            this.btnLaptop.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnLaptop.Font = new System.Drawing.Font("Lucida Sans Typewriter", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnLaptop.ForeColor = System.Drawing.Color.White;
            this.btnLaptop.Location = new System.Drawing.Point(0, 120);
            this.btnLaptop.Margin = new System.Windows.Forms.Padding(0);
            this.btnLaptop.Name = "btnLaptop";
            this.btnLaptop.Padding = new System.Windows.Forms.Padding(0, 10, 0, 0);
            this.btnLaptop.Size = new System.Drawing.Size(207, 60);
            this.btnLaptop.TabIndex = 2;
            this.btnLaptop.Text = "Laptop ";
            this.btnLaptop.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnLaptop.UseVisualStyleBackColor = true;
            // 
            // btnTelevizoare
            // 
            this.btnTelevizoare.Dock = System.Windows.Forms.DockStyle.Top;
            this.btnTelevizoare.FlatAppearance.BorderSize = 0;
            this.btnTelevizoare.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnTelevizoare.Font = new System.Drawing.Font("Lucida Sans Typewriter", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnTelevizoare.ForeColor = System.Drawing.Color.White;
            this.btnTelevizoare.Location = new System.Drawing.Point(0, 60);
            this.btnTelevizoare.Margin = new System.Windows.Forms.Padding(0);
            this.btnTelevizoare.Name = "btnTelevizoare";
            this.btnTelevizoare.Padding = new System.Windows.Forms.Padding(0, 10, 0, 0);
            this.btnTelevizoare.Size = new System.Drawing.Size(207, 60);
            this.btnTelevizoare.TabIndex = 1;
            this.btnTelevizoare.Text = "Televizoare";
            this.btnTelevizoare.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnTelevizoare.UseVisualStyleBackColor = true;
            // 
            // btnSmartphone
            // 
            this.btnSmartphone.Dock = System.Windows.Forms.DockStyle.Top;
            this.btnSmartphone.FlatAppearance.BorderSize = 0;
            this.btnSmartphone.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnSmartphone.Font = new System.Drawing.Font("Lucida Sans Typewriter", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSmartphone.ForeColor = System.Drawing.Color.White;
            this.btnSmartphone.Location = new System.Drawing.Point(0, 0);
            this.btnSmartphone.Margin = new System.Windows.Forms.Padding(0);
            this.btnSmartphone.Name = "btnSmartphone";
            this.btnSmartphone.Padding = new System.Windows.Forms.Padding(0, 10, 0, 0);
            this.btnSmartphone.Size = new System.Drawing.Size(207, 60);
            this.btnSmartphone.TabIndex = 0;
            this.btnSmartphone.Text = "Smartphone";
            this.btnSmartphone.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnSmartphone.UseVisualStyleBackColor = true;
            this.btnSmartphone.Click += new System.EventHandler(this.btnCategorie1_Click);
            // 
            // lblCategorii
            // 
            this.lblCategorii.AutoSize = true;
            this.lblCategorii.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(239)))), ((int)(((byte)(131)))), ((int)(((byte)(84)))));
            this.lblCategorii.Dock = System.Windows.Forms.DockStyle.Top;
            this.lblCategorii.Font = new System.Drawing.Font("Lucida Sans", 15F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblCategorii.Location = new System.Drawing.Point(0, 0);
            this.lblCategorii.Margin = new System.Windows.Forms.Padding(0);
            this.lblCategorii.Name = "lblCategorii";
            this.lblCategorii.Padding = new System.Windows.Forms.Padding(5, 20, 9, 20);
            this.lblCategorii.Size = new System.Drawing.Size(213, 63);
            this.lblCategorii.TabIndex = 0;
            this.lblCategorii.Text = "Categorii Produse";
            this.lblCategorii.Click += new System.EventHandler(this.lblCategorii_Click);
            // 
            // pnlMain
            // 
            this.pnlMain.AutoScroll = true;
            this.pnlMain.AutoScrollMargin = new System.Drawing.Size(0, 700);
            this.pnlMain.BackColor = System.Drawing.Color.White;
            this.pnlMain.Controls.Add(this.pnlTopBar);
            this.pnlMain.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pnlMain.Location = new System.Drawing.Point(207, 0);
            this.pnlMain.Name = "pnlMain";
            this.pnlMain.Size = new System.Drawing.Size(758, 810);
            this.pnlMain.TabIndex = 1;
            // 
            // pnlTopBar
            // 
            this.pnlTopBar.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(239)))), ((int)(((byte)(131)))), ((int)(((byte)(84)))));
            this.pnlTopBar.Controls.Add(this.btnCos);
            this.pnlTopBar.Dock = System.Windows.Forms.DockStyle.Top;
            this.pnlTopBar.Location = new System.Drawing.Point(0, 0);
            this.pnlTopBar.Name = "pnlTopBar";
            this.pnlTopBar.Size = new System.Drawing.Size(758, 63);
            this.pnlTopBar.TabIndex = 0;
            // 
            // btnCos
            // 
            this.btnCos.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.btnCos.BackgroundImage = global::Magazin.ResourcesSmartphone.NicePng_cart_png_images_2534370;
            this.btnCos.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.btnCos.Dock = System.Windows.Forms.DockStyle.Right;
            this.btnCos.FlatAppearance.BorderSize = 0;
            this.btnCos.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnCos.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.btnCos.ForeColor = System.Drawing.Color.White;
            this.btnCos.Location = new System.Drawing.Point(700, 0);
            this.btnCos.MaximumSize = new System.Drawing.Size(58, 63);
            this.btnCos.Name = "btnCos";
            this.btnCos.Size = new System.Drawing.Size(58, 63);
            this.btnCos.TabIndex = 0;
            this.btnCos.Text = "0.00Ron";
            this.btnCos.TextAlign = System.Drawing.ContentAlignment.BottomRight;
            this.btnCos.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.btnCos.UseVisualStyleBackColor = true;
            // 
            // frmSmartphones
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoScroll = true;
            this.AutoScrollMargin = new System.Drawing.Size(700, 0);
            this.ClientSize = new System.Drawing.Size(965, 810);
            this.Controls.Add(this.pnlMain);
            this.Controls.Add(this.pnlNav);
            this.DoubleBuffered = true;
            this.Name = "frmSmartphones";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "DejMag";
            this.pnlNav.ResumeLayout(false);
            this.pnlNav.PerformLayout();
            this.pnlScroll.ResumeLayout(false);
            this.pnlMain.ResumeLayout(false);
            this.pnlTopBar.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel pnlNav;
        private System.Windows.Forms.Panel pnlMain;
        private System.Windows.Forms.Panel pnlScroll;
        private System.Windows.Forms.Panel pnlTopBar;
        private System.Windows.Forms.Button btnSmartphone;
        private System.Windows.Forms.Button btnElectrocasnice;
        private System.Windows.Forms.Button btnDesktop;
        private System.Windows.Forms.Button btnLaptop;
        private System.Windows.Forms.Button btnTelevizoare;
        private System.Windows.Forms.Label lblCategorii;
        private System.Windows.Forms.Button btnWearables;
        private System.Windows.Forms.Button btnFoto;
        private System.Windows.Forms.Button btnConsole;
        private System.Windows.Forms.Button btnAudio;
        private System.Windows.Forms.Button btnCos;
    }
}

