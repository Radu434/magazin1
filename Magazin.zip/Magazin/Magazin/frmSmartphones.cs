﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Magazin
{
    public partial class frmSmartphones : Form
    {
        public frmSmartphones()
        {
            InitializeComponent();
        
        }

        private void lblCategorii_Click(object sender, EventArgs e)
        {
            
        }

        private void btnCategorie1_Click(object sender, EventArgs e)
        {
            
          //form cos + form smartphone copiat dupa ala original+ form pt produs idividual
        
        }
    }
}
