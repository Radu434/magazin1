﻿namespace Magazin
{
    partial class frmMain
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.pnlNav = new System.Windows.Forms.Panel();
            this.pnlScroll = new System.Windows.Forms.Panel();
            this.btnWearables = new System.Windows.Forms.Button();
            this.btnFoto = new System.Windows.Forms.Button();
            this.btnConsole = new System.Windows.Forms.Button();
            this.btnAudio = new System.Windows.Forms.Button();
            this.btnElectrocasnice = new System.Windows.Forms.Button();
            this.btnDesktop = new System.Windows.Forms.Button();
            this.btnLaptop = new System.Windows.Forms.Button();
            this.btnTelevizoare = new System.Windows.Forms.Button();
            this.btnSmartphone = new System.Windows.Forms.Button();
            this.lblCategorii = new System.Windows.Forms.Label();
            this.pnlMain = new System.Windows.Forms.Panel();
            this.tblOferta = new System.Windows.Forms.TableLayoutPanel();
            this.btnTelevizor2 = new System.Windows.Forms.Button();
            this.pnlTopBar = new System.Windows.Forms.Panel();
            this.btnCos = new System.Windows.Forms.Button();
            this.btnSmartphone2 = new System.Windows.Forms.Button();
            this.pnlOferta = new System.Windows.Forms.Panel();
            this.btnDesktop2 = new System.Windows.Forms.Button();
            this.btnLaptop2 = new System.Windows.Forms.Button();
            this.btnElectrocasnice2 = new System.Windows.Forms.Button();
            this.btnAudio2 = new System.Windows.Forms.Button();
            this.btnConsole2 = new System.Windows.Forms.Button();
            this.btnFoto2 = new System.Windows.Forms.Button();
            this.btnWearables2 = new System.Windows.Forms.Button();
            this.pnlNav.SuspendLayout();
            this.pnlScroll.SuspendLayout();
            this.pnlMain.SuspendLayout();
            this.tblOferta.SuspendLayout();
            this.pnlTopBar.SuspendLayout();
            this.pnlOferta.SuspendLayout();
            this.SuspendLayout();
            // 
            // pnlNav
            // 
            this.pnlNav.Controls.Add(this.pnlScroll);
            this.pnlNav.Controls.Add(this.lblCategorii);
            this.pnlNav.Dock = System.Windows.Forms.DockStyle.Left;
            this.pnlNav.Location = new System.Drawing.Point(0, 0);
            this.pnlNav.Name = "pnlNav";
            this.pnlNav.Size = new System.Drawing.Size(207, 810);
            this.pnlNav.TabIndex = 0;
            // 
            // pnlScroll
            // 
            this.pnlScroll.AutoScroll = true;
            this.pnlScroll.AutoScrollMargin = new System.Drawing.Size(0, 50);
            this.pnlScroll.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(79)))), ((int)(((byte)(93)))), ((int)(((byte)(117)))));
            this.pnlScroll.Controls.Add(this.btnWearables);
            this.pnlScroll.Controls.Add(this.btnFoto);
            this.pnlScroll.Controls.Add(this.btnConsole);
            this.pnlScroll.Controls.Add(this.btnAudio);
            this.pnlScroll.Controls.Add(this.btnElectrocasnice);
            this.pnlScroll.Controls.Add(this.btnDesktop);
            this.pnlScroll.Controls.Add(this.btnLaptop);
            this.pnlScroll.Controls.Add(this.btnTelevizoare);
            this.pnlScroll.Controls.Add(this.btnSmartphone);
            this.pnlScroll.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pnlScroll.Location = new System.Drawing.Point(0, 63);
            this.pnlScroll.Name = "pnlScroll";
            this.pnlScroll.Size = new System.Drawing.Size(207, 747);
            this.pnlScroll.TabIndex = 0;
            // 
            // btnWearables
            // 
            this.btnWearables.Dock = System.Windows.Forms.DockStyle.Top;
            this.btnWearables.FlatAppearance.BorderSize = 0;
            this.btnWearables.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnWearables.Font = new System.Drawing.Font("Lucida Sans Typewriter", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnWearables.ForeColor = System.Drawing.Color.White;
            this.btnWearables.Location = new System.Drawing.Point(0, 480);
            this.btnWearables.Margin = new System.Windows.Forms.Padding(0);
            this.btnWearables.Name = "btnWearables";
            this.btnWearables.Padding = new System.Windows.Forms.Padding(0, 10, 0, 0);
            this.btnWearables.Size = new System.Drawing.Size(207, 60);
            this.btnWearables.TabIndex = 11;
            this.btnWearables.Text = "Wearables";
            this.btnWearables.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnWearables.UseVisualStyleBackColor = true;
            // 
            // btnFoto
            // 
            this.btnFoto.Dock = System.Windows.Forms.DockStyle.Top;
            this.btnFoto.FlatAppearance.BorderSize = 0;
            this.btnFoto.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnFoto.Font = new System.Drawing.Font("Lucida Sans Typewriter", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnFoto.ForeColor = System.Drawing.Color.White;
            this.btnFoto.Location = new System.Drawing.Point(0, 420);
            this.btnFoto.Margin = new System.Windows.Forms.Padding(0);
            this.btnFoto.Name = "btnFoto";
            this.btnFoto.Padding = new System.Windows.Forms.Padding(0, 10, 0, 0);
            this.btnFoto.Size = new System.Drawing.Size(207, 60);
            this.btnFoto.TabIndex = 10;
            this.btnFoto.Text = "Foto";
            this.btnFoto.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnFoto.UseVisualStyleBackColor = true;
            // 
            // btnConsole
            // 
            this.btnConsole.Dock = System.Windows.Forms.DockStyle.Top;
            this.btnConsole.FlatAppearance.BorderSize = 0;
            this.btnConsole.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnConsole.Font = new System.Drawing.Font("Lucida Sans Typewriter", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnConsole.ForeColor = System.Drawing.Color.White;
            this.btnConsole.Location = new System.Drawing.Point(0, 360);
            this.btnConsole.Margin = new System.Windows.Forms.Padding(0);
            this.btnConsole.Name = "btnConsole";
            this.btnConsole.Padding = new System.Windows.Forms.Padding(0, 10, 0, 0);
            this.btnConsole.Size = new System.Drawing.Size(207, 60);
            this.btnConsole.TabIndex = 9;
            this.btnConsole.Text = "Console Jocuri";
            this.btnConsole.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnConsole.UseVisualStyleBackColor = true;
            // 
            // btnAudio
            // 
            this.btnAudio.Dock = System.Windows.Forms.DockStyle.Top;
            this.btnAudio.FlatAppearance.BorderSize = 0;
            this.btnAudio.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnAudio.Font = new System.Drawing.Font("Lucida Sans Typewriter", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnAudio.ForeColor = System.Drawing.Color.White;
            this.btnAudio.Location = new System.Drawing.Point(0, 300);
            this.btnAudio.Margin = new System.Windows.Forms.Padding(0);
            this.btnAudio.Name = "btnAudio";
            this.btnAudio.Padding = new System.Windows.Forms.Padding(0, 10, 0, 0);
            this.btnAudio.Size = new System.Drawing.Size(207, 60);
            this.btnAudio.TabIndex = 8;
            this.btnAudio.Text = "Audio";
            this.btnAudio.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnAudio.UseVisualStyleBackColor = true;
            // 
            // btnElectrocasnice
            // 
            this.btnElectrocasnice.Dock = System.Windows.Forms.DockStyle.Top;
            this.btnElectrocasnice.FlatAppearance.BorderSize = 0;
            this.btnElectrocasnice.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnElectrocasnice.Font = new System.Drawing.Font("Lucida Sans Typewriter", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnElectrocasnice.ForeColor = System.Drawing.Color.White;
            this.btnElectrocasnice.Location = new System.Drawing.Point(0, 240);
            this.btnElectrocasnice.Margin = new System.Windows.Forms.Padding(0);
            this.btnElectrocasnice.Name = "btnElectrocasnice";
            this.btnElectrocasnice.Padding = new System.Windows.Forms.Padding(0, 10, 0, 0);
            this.btnElectrocasnice.Size = new System.Drawing.Size(207, 60);
            this.btnElectrocasnice.TabIndex = 4;
            this.btnElectrocasnice.Text = "Electrocasnice";
            this.btnElectrocasnice.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnElectrocasnice.UseVisualStyleBackColor = true;
            // 
            // btnDesktop
            // 
            this.btnDesktop.Dock = System.Windows.Forms.DockStyle.Top;
            this.btnDesktop.FlatAppearance.BorderSize = 0;
            this.btnDesktop.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnDesktop.Font = new System.Drawing.Font("Lucida Sans Typewriter", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnDesktop.ForeColor = System.Drawing.Color.White;
            this.btnDesktop.Location = new System.Drawing.Point(0, 180);
            this.btnDesktop.Margin = new System.Windows.Forms.Padding(0);
            this.btnDesktop.Name = "btnDesktop";
            this.btnDesktop.Padding = new System.Windows.Forms.Padding(0, 10, 0, 0);
            this.btnDesktop.Size = new System.Drawing.Size(207, 60);
            this.btnDesktop.TabIndex = 3;
            this.btnDesktop.Text = "Desktop";
            this.btnDesktop.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnDesktop.UseVisualStyleBackColor = true;
            // 
            // btnLaptop
            // 
            this.btnLaptop.Dock = System.Windows.Forms.DockStyle.Top;
            this.btnLaptop.FlatAppearance.BorderSize = 0;
            this.btnLaptop.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnLaptop.Font = new System.Drawing.Font("Lucida Sans Typewriter", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnLaptop.ForeColor = System.Drawing.Color.White;
            this.btnLaptop.Location = new System.Drawing.Point(0, 120);
            this.btnLaptop.Margin = new System.Windows.Forms.Padding(0);
            this.btnLaptop.Name = "btnLaptop";
            this.btnLaptop.Padding = new System.Windows.Forms.Padding(0, 10, 0, 0);
            this.btnLaptop.Size = new System.Drawing.Size(207, 60);
            this.btnLaptop.TabIndex = 2;
            this.btnLaptop.Text = "Laptop ";
            this.btnLaptop.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnLaptop.UseVisualStyleBackColor = true;
            // 
            // btnTelevizoare
            // 
            this.btnTelevizoare.Dock = System.Windows.Forms.DockStyle.Top;
            this.btnTelevizoare.FlatAppearance.BorderSize = 0;
            this.btnTelevizoare.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnTelevizoare.Font = new System.Drawing.Font("Lucida Sans Typewriter", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnTelevizoare.ForeColor = System.Drawing.Color.White;
            this.btnTelevizoare.Location = new System.Drawing.Point(0, 60);
            this.btnTelevizoare.Margin = new System.Windows.Forms.Padding(0);
            this.btnTelevizoare.Name = "btnTelevizoare";
            this.btnTelevizoare.Padding = new System.Windows.Forms.Padding(0, 10, 0, 0);
            this.btnTelevizoare.Size = new System.Drawing.Size(207, 60);
            this.btnTelevizoare.TabIndex = 1;
            this.btnTelevizoare.Text = "Televizoare";
            this.btnTelevizoare.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnTelevizoare.UseVisualStyleBackColor = true;
            // 
            // btnSmartphone
            // 
            this.btnSmartphone.Dock = System.Windows.Forms.DockStyle.Top;
            this.btnSmartphone.FlatAppearance.BorderSize = 0;
            this.btnSmartphone.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnSmartphone.Font = new System.Drawing.Font("Lucida Sans Typewriter", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSmartphone.ForeColor = System.Drawing.Color.White;
            this.btnSmartphone.Location = new System.Drawing.Point(0, 0);
            this.btnSmartphone.Margin = new System.Windows.Forms.Padding(0);
            this.btnSmartphone.Name = "btnSmartphone";
            this.btnSmartphone.Padding = new System.Windows.Forms.Padding(0, 10, 0, 0);
            this.btnSmartphone.Size = new System.Drawing.Size(207, 60);
            this.btnSmartphone.TabIndex = 0;
            this.btnSmartphone.Text = "Smartphone";
            this.btnSmartphone.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnSmartphone.UseVisualStyleBackColor = true;
            this.btnSmartphone.Click += new System.EventHandler(this.btnCategorie1_Click);
            // 
            // lblCategorii
            // 
            this.lblCategorii.AutoSize = true;
            this.lblCategorii.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(239)))), ((int)(((byte)(131)))), ((int)(((byte)(84)))));
            this.lblCategorii.Dock = System.Windows.Forms.DockStyle.Top;
            this.lblCategorii.Font = new System.Drawing.Font("Lucida Sans", 15F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblCategorii.Location = new System.Drawing.Point(0, 0);
            this.lblCategorii.Margin = new System.Windows.Forms.Padding(0);
            this.lblCategorii.Name = "lblCategorii";
            this.lblCategorii.Padding = new System.Windows.Forms.Padding(5, 20, 9, 20);
            this.lblCategorii.Size = new System.Drawing.Size(213, 63);
            this.lblCategorii.TabIndex = 0;
            this.lblCategorii.Text = "Categorii Produse";
            this.lblCategorii.Click += new System.EventHandler(this.lblCategorii_Click);
            // 
            // pnlMain
            // 
            this.pnlMain.AutoScroll = true;
            this.pnlMain.AutoScrollMargin = new System.Drawing.Size(0, 700);
            this.pnlMain.BackColor = System.Drawing.Color.White;
            this.pnlMain.Controls.Add(this.tblOferta);
            this.pnlMain.Controls.Add(this.pnlTopBar);
            this.pnlMain.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pnlMain.Location = new System.Drawing.Point(207, 0);
            this.pnlMain.Name = "pnlMain";
            this.pnlMain.Size = new System.Drawing.Size(758, 810);
            this.pnlMain.TabIndex = 1;
            // 
            // tblOferta
            // 
            this.tblOferta.AutoScroll = true;
            this.tblOferta.AutoScrollMargin = new System.Drawing.Size(0, 10);
            this.tblOferta.BackColor = System.Drawing.Color.LightGray;
            this.tblOferta.ColumnCount = 3;
            this.tblOferta.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 33.33333F));
            this.tblOferta.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 33.33334F));
            this.tblOferta.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 33.33334F));
            this.tblOferta.Controls.Add(this.btnWearables2, 2, 2);
            this.tblOferta.Controls.Add(this.btnFoto2, 1, 2);
            this.tblOferta.Controls.Add(this.btnConsole2, 0, 2);
            this.tblOferta.Controls.Add(this.btnAudio2, 2, 1);
            this.tblOferta.Controls.Add(this.btnElectrocasnice2, 1, 1);
            this.tblOferta.Controls.Add(this.btnLaptop2, 2, 0);
            this.tblOferta.Controls.Add(this.btnDesktop2, 0, 1);
            this.tblOferta.Controls.Add(this.pnlOferta, 0, 0);
            this.tblOferta.Controls.Add(this.btnTelevizor2, 1, 0);
            this.tblOferta.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tblOferta.Location = new System.Drawing.Point(0, 63);
            this.tblOferta.MinimumSize = new System.Drawing.Size(246, 745);
            this.tblOferta.Name = "tblOferta";
            this.tblOferta.RowCount = 3;
            this.tblOferta.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 33.33332F));
            this.tblOferta.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 33.33334F));
            this.tblOferta.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 33.33334F));
            this.tblOferta.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tblOferta.Size = new System.Drawing.Size(758, 747);
            this.tblOferta.TabIndex = 1;
            this.tblOferta.Paint += new System.Windows.Forms.PaintEventHandler(this.tblOferta_Paint);
            // 
            // btnTelevizor2
            // 
            this.btnTelevizor2.BackColor = System.Drawing.Color.White;
            this.btnTelevizor2.BackgroundImage = global::Magazin.ResourcesSmartphone._43PUS7394_12_IMS_ro_RO;
            this.btnTelevizor2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.btnTelevizor2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.btnTelevizor2.Font = new System.Drawing.Font("Lucida Sans", 27F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnTelevizor2.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.btnTelevizor2.Location = new System.Drawing.Point(255, 3);
            this.btnTelevizor2.Name = "btnTelevizor2";
            this.btnTelevizor2.Size = new System.Drawing.Size(246, 242);
            this.btnTelevizor2.TabIndex = 9;
            this.btnTelevizor2.Text = "Televizoare";
            this.btnTelevizor2.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.btnTelevizor2.UseVisualStyleBackColor = false;
            this.btnTelevizor2.Click += new System.EventHandler(this.btnTelevizor2_Click);
            // 
            // pnlTopBar
            // 
            this.pnlTopBar.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.pnlTopBar.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(239)))), ((int)(((byte)(131)))), ((int)(((byte)(84)))));
            this.pnlTopBar.Controls.Add(this.btnCos);
            this.pnlTopBar.Dock = System.Windows.Forms.DockStyle.Top;
            this.pnlTopBar.Location = new System.Drawing.Point(0, 0);
            this.pnlTopBar.Name = "pnlTopBar";
            this.pnlTopBar.Size = new System.Drawing.Size(758, 63);
            this.pnlTopBar.TabIndex = 0;
            // 
            // btnCos
            // 
            this.btnCos.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.btnCos.BackgroundImage = global::Magazin.ResourcesSmartphone.NicePng_cart_png_images_2534370;
            this.btnCos.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.btnCos.Dock = System.Windows.Forms.DockStyle.Right;
            this.btnCos.FlatAppearance.BorderSize = 0;
            this.btnCos.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnCos.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.btnCos.ForeColor = System.Drawing.Color.White;
            this.btnCos.Location = new System.Drawing.Point(700, 0);
            this.btnCos.MaximumSize = new System.Drawing.Size(58, 63);
            this.btnCos.Name = "btnCos";
            this.btnCos.Size = new System.Drawing.Size(58, 63);
            this.btnCos.TabIndex = 0;
            this.btnCos.Text = "0.00Ron";
            this.btnCos.TextAlign = System.Drawing.ContentAlignment.BottomRight;
            this.btnCos.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.btnCos.UseVisualStyleBackColor = true;
            // 
            // btnSmartphone2
            // 
            this.btnSmartphone2.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.btnSmartphone2.BackColor = System.Drawing.Color.White;
            this.btnSmartphone2.BackgroundImage = global::Magazin.ResourcesSmartphone.Iphone_12_Pro_Max;
            this.btnSmartphone2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.btnSmartphone2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.btnSmartphone2.Font = new System.Drawing.Font("Lucida Sans", 27.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSmartphone2.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.btnSmartphone2.Location = new System.Drawing.Point(0, 0);
            this.btnSmartphone2.Name = "btnSmartphone2";
            this.btnSmartphone2.Size = new System.Drawing.Size(248, 244);
            this.btnSmartphone2.TabIndex = 0;
            this.btnSmartphone2.Text = "Smartphone";
            this.btnSmartphone2.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.btnSmartphone2.UseVisualStyleBackColor = false;
            // 
            // pnlOferta
            // 
            this.pnlOferta.Controls.Add(this.btnSmartphone2);
            this.pnlOferta.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pnlOferta.Location = new System.Drawing.Point(2, 2);
            this.pnlOferta.Margin = new System.Windows.Forms.Padding(2);
            this.pnlOferta.Name = "pnlOferta";
            this.pnlOferta.Size = new System.Drawing.Size(248, 244);
            this.pnlOferta.TabIndex = 0;
            // 
            // btnDesktop2
            // 
            this.btnDesktop2.BackColor = System.Drawing.Color.White;
            this.btnDesktop2.BackgroundImage = global::Magazin.ResourcesSmartphone.new_category_page_desktop_inspiron_27_7790_3880_800x620;
            this.btnDesktop2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.btnDesktop2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.btnDesktop2.Font = new System.Drawing.Font("Lucida Sans", 27F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnDesktop2.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.btnDesktop2.Location = new System.Drawing.Point(3, 251);
            this.btnDesktop2.Name = "btnDesktop2";
            this.btnDesktop2.Size = new System.Drawing.Size(246, 243);
            this.btnDesktop2.TabIndex = 11;
            this.btnDesktop2.Text = "Desktop";
            this.btnDesktop2.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.btnDesktop2.UseVisualStyleBackColor = false;
            // 
            // btnLaptop2
            // 
            this.btnLaptop2.BackColor = System.Drawing.Color.White;
            this.btnLaptop2.BackgroundImage = global::Magazin.ResourcesSmartphone.res_71082d5f26440a373819caebfa6ead24;
            this.btnLaptop2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.btnLaptop2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.btnLaptop2.Font = new System.Drawing.Font("Lucida Sans", 27F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnLaptop2.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.btnLaptop2.Location = new System.Drawing.Point(507, 3);
            this.btnLaptop2.Name = "btnLaptop2";
            this.btnLaptop2.Size = new System.Drawing.Size(248, 242);
            this.btnLaptop2.TabIndex = 12;
            this.btnLaptop2.Text = "Laptop";
            this.btnLaptop2.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.btnLaptop2.UseVisualStyleBackColor = false;
            // 
            // btnElectrocasnice2
            // 
            this.btnElectrocasnice2.BackColor = System.Drawing.Color.White;
            this.btnElectrocasnice2.BackgroundImage = global::Magazin.ResourcesSmartphone.electrocasnice;
            this.btnElectrocasnice2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.btnElectrocasnice2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.btnElectrocasnice2.Font = new System.Drawing.Font("Lucida Sans", 24F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnElectrocasnice2.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.btnElectrocasnice2.Location = new System.Drawing.Point(255, 251);
            this.btnElectrocasnice2.Name = "btnElectrocasnice2";
            this.btnElectrocasnice2.Size = new System.Drawing.Size(246, 243);
            this.btnElectrocasnice2.TabIndex = 13;
            this.btnElectrocasnice2.Text = "Electrocasnice";
            this.btnElectrocasnice2.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.btnElectrocasnice2.UseVisualStyleBackColor = false;
            // 
            // btnAudio2
            // 
            this.btnAudio2.BackColor = System.Drawing.Color.White;
            this.btnAudio2.BackgroundImage = global::Magazin.ResourcesSmartphone.AR_Accurate1200;
            this.btnAudio2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.btnAudio2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.btnAudio2.Font = new System.Drawing.Font("Lucida Sans", 27F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnAudio2.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.btnAudio2.Location = new System.Drawing.Point(507, 251);
            this.btnAudio2.Name = "btnAudio2";
            this.btnAudio2.Size = new System.Drawing.Size(248, 243);
            this.btnAudio2.TabIndex = 14;
            this.btnAudio2.Text = "Audio";
            this.btnAudio2.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.btnAudio2.UseVisualStyleBackColor = false;
            // 
            // btnConsole2
            // 
            this.btnConsole2.BackColor = System.Drawing.Color.White;
            this.btnConsole2.BackgroundImage = global::Magazin.ResourcesSmartphone.Gaming_Consoles;
            this.btnConsole2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.btnConsole2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.btnConsole2.Font = new System.Drawing.Font("Lucida Sans", 21.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnConsole2.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.btnConsole2.Location = new System.Drawing.Point(3, 500);
            this.btnConsole2.Name = "btnConsole2";
            this.btnConsole2.Size = new System.Drawing.Size(246, 244);
            this.btnConsole2.TabIndex = 15;
            this.btnConsole2.Text = "Console Jocuri";
            this.btnConsole2.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.btnConsole2.UseVisualStyleBackColor = false;
            // 
            // btnFoto2
            // 
            this.btnFoto2.BackColor = System.Drawing.Color.White;
            this.btnFoto2.BackgroundImage = global::Magazin.ResourcesSmartphone._1590_D3500_left_61f9af46;
            this.btnFoto2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.btnFoto2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.btnFoto2.Font = new System.Drawing.Font("Lucida Sans", 27F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnFoto2.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.btnFoto2.Location = new System.Drawing.Point(255, 500);
            this.btnFoto2.Name = "btnFoto2";
            this.btnFoto2.Size = new System.Drawing.Size(246, 244);
            this.btnFoto2.TabIndex = 16;
            this.btnFoto2.Text = "Foto";
            this.btnFoto2.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.btnFoto2.UseVisualStyleBackColor = false;
            // 
            // btnWearables2
            // 
            this.btnWearables2.BackColor = System.Drawing.Color.White;
            this.btnWearables2.BackgroundImage = global::Magazin.ResourcesSmartphone.watchos6_series5_bluetooth_hero_wrap;
            this.btnWearables2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.btnWearables2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.btnWearables2.Font = new System.Drawing.Font("Lucida Sans", 27F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnWearables2.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.btnWearables2.Location = new System.Drawing.Point(507, 500);
            this.btnWearables2.Name = "btnWearables2";
            this.btnWearables2.Size = new System.Drawing.Size(248, 244);
            this.btnWearables2.TabIndex = 17;
            this.btnWearables2.Text = "Wearables";
            this.btnWearables2.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.btnWearables2.UseVisualStyleBackColor = false;
            // 
            // frmMain
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoScrollMargin = new System.Drawing.Size(700, 0);
            this.ClientSize = new System.Drawing.Size(965, 810);
            this.Controls.Add(this.pnlMain);
            this.Controls.Add(this.pnlNav);
            this.DoubleBuffered = true;
            this.IsMdiContainer = true;
            this.Name = "frmMain";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "DejMag";
            this.pnlNav.ResumeLayout(false);
            this.pnlNav.PerformLayout();
            this.pnlScroll.ResumeLayout(false);
            this.pnlMain.ResumeLayout(false);
            this.tblOferta.ResumeLayout(false);
            this.pnlTopBar.ResumeLayout(false);
            this.pnlOferta.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel pnlNav;
        private System.Windows.Forms.Panel pnlMain;
        private System.Windows.Forms.Panel pnlScroll;
        private System.Windows.Forms.Panel pnlTopBar;
        private System.Windows.Forms.Button btnSmartphone;
        private System.Windows.Forms.Button btnElectrocasnice;
        private System.Windows.Forms.Button btnDesktop;
        private System.Windows.Forms.Button btnLaptop;
        private System.Windows.Forms.Button btnTelevizoare;
        private System.Windows.Forms.Label lblCategorii;
        private System.Windows.Forms.TableLayoutPanel tblOferta;
        private System.Windows.Forms.Button btnWearables;
        private System.Windows.Forms.Button btnFoto;
        private System.Windows.Forms.Button btnConsole;
        private System.Windows.Forms.Button btnAudio;
        private System.Windows.Forms.Button btnCos;
        private System.Windows.Forms.Button btnTelevizor2;
        private System.Windows.Forms.Panel pnlOferta;
        private System.Windows.Forms.Button btnSmartphone2;
        private System.Windows.Forms.Button btnWearables2;
        private System.Windows.Forms.Button btnFoto2;
        private System.Windows.Forms.Button btnConsole2;
        private System.Windows.Forms.Button btnAudio2;
        private System.Windows.Forms.Button btnElectrocasnice2;
        private System.Windows.Forms.Button btnLaptop2;
        private System.Windows.Forms.Button btnDesktop2;
    }
}

