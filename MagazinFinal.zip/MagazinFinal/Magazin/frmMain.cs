﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Magazin
{
    public partial class frmMain : Form
    {
        double valCos = 0;
        bool cosDeschis = false;
        bool altTab = false;
        public frmMain()
        {
            InitializeComponent();
        
        }

        private void lblCategorii_Click(object sender, EventArgs e)
        {
            
        }

        private void btnCategorie1_Click(object sender, EventArgs e)
        {

            

        }

        private void btnTelevizor2_Click(object sender, EventArgs e)
        {

        }

        private void tblOferta_Paint(object sender, PaintEventArgs e)
        {

        }
       public void deschideCos()
        {
           if(cosDeschis==true)
            {
                cosDeschis = false;
                pnlTopBar.Height =  63;
                pnlCos.Visible = false;
                btnBack.Visible = false;
                btnStergElem.Visible = false;
                btnComanda.Visible = false;
                if(altTab==true)
                {
                    btnBack.Visible = true;

                }
            }
           else
            {
                cosDeschis = true;
                pnlTopBar.Height = frmMain.ActiveForm.Height / 2;
                pnlCos.Visible = true;
                btnBack.Visible = false;
                btnStergElem.Visible = true;
                btnComanda.Visible = true;

            }
        }

        private void btnSmartphone2_Click(object sender, EventArgs e)
        {
            tblOferta.Visible = false;
            tblTelefoane.Visible = true;
            if(cosDeschis==false)
            {
            btnBack.Visible = true;

            }
            altTab = true;
        }

        private void btnBack_Click(object sender, EventArgs e)
        {
            tblOferta.Visible = true;
            tblTelefoane.Visible = false;
            btnBack.Visible = false;
        }

        private void btnCosTel1_Click(object sender, EventArgs e)
        {
            valCos += 5000;
            lblValCos.Text = valCos.ToString() +" Ron";
            lstCos.Items.Add("Samsung Galaxy S21 5000 Ron");
            lstPreturi.Items.Add("5000");
        }

        private void btnCos_Click(object sender, EventArgs e)
        {
            deschideCos();

        }

        private void btnGolCos_Click(object sender, EventArgs e)
        {
            lstCos.Items.Clear();
            lstPreturi.Items.Clear();
            valCos = 0;
            lblValCos.Text = valCos.ToString() + " Ron";

        }

        private void btnStergElem_Click(object sender, EventArgs e)
        {
            if (lstCos.SelectedIndex != -1) 
            { 
                double aux = 0;
                int i = lstCos.SelectedIndex;
                Double.TryParse(lstPreturi.Items[i].ToString(), out aux);
                lstPreturi.Items.Remove(lstPreturi.Items[i]);
                lstCos.Items.Remove(lstCos.SelectedItem);
                valCos = valCos - aux;
                lblValCos.Text = valCos.ToString() + " Ron";
                aux = 0;
            }
        
            else

            {
                MessageBox.Show("Nu ai selectat ici un element!");
             }
          
            
        }

        private void button2_Click(object sender, EventArgs e)
        {
            valCos += 3000;
            lblValCos.Text = valCos.ToString() + " Ron";
            lstCos.Items.Add("Huawei P40 3000 Ron");
            lstPreturi.Items.Add("3000");
        }
    }
}
