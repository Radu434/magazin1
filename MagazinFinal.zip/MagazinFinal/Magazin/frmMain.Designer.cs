﻿namespace Magazin
{
    partial class frmMain
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmMain));
            this.pnlMain = new System.Windows.Forms.Panel();
            this.tblTelefoane = new System.Windows.Forms.TableLayoutPanel();
            this.panel11 = new System.Windows.Forms.Panel();
            this.button21 = new System.Windows.Forms.Button();
            this.button22 = new System.Windows.Forms.Button();
            this.panel10 = new System.Windows.Forms.Panel();
            this.button19 = new System.Windows.Forms.Button();
            this.button20 = new System.Windows.Forms.Button();
            this.panel9 = new System.Windows.Forms.Panel();
            this.button17 = new System.Windows.Forms.Button();
            this.button18 = new System.Windows.Forms.Button();
            this.panel8 = new System.Windows.Forms.Panel();
            this.button15 = new System.Windows.Forms.Button();
            this.button16 = new System.Windows.Forms.Button();
            this.panel7 = new System.Windows.Forms.Panel();
            this.button13 = new System.Windows.Forms.Button();
            this.button14 = new System.Windows.Forms.Button();
            this.panel6 = new System.Windows.Forms.Panel();
            this.button11 = new System.Windows.Forms.Button();
            this.button12 = new System.Windows.Forms.Button();
            this.panel5 = new System.Windows.Forms.Panel();
            this.button9 = new System.Windows.Forms.Button();
            this.button10 = new System.Windows.Forms.Button();
            this.panel4 = new System.Windows.Forms.Panel();
            this.button7 = new System.Windows.Forms.Button();
            this.button8 = new System.Windows.Forms.Button();
            this.panel3 = new System.Windows.Forms.Panel();
            this.button5 = new System.Windows.Forms.Button();
            this.button6 = new System.Windows.Forms.Button();
            this.panel2 = new System.Windows.Forms.Panel();
            this.button3 = new System.Windows.Forms.Button();
            this.button4 = new System.Windows.Forms.Button();
            this.panel1 = new System.Windows.Forms.Panel();
            this.button1 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.pnlElementTelefoane = new System.Windows.Forms.Panel();
            this.btnPagElem1 = new System.Windows.Forms.Button();
            this.btnCosTel1 = new System.Windows.Forms.Button();
            this.tblOferta = new System.Windows.Forms.TableLayoutPanel();
            this.btnWearables2 = new System.Windows.Forms.Button();
            this.btnFoto2 = new System.Windows.Forms.Button();
            this.btnConsole2 = new System.Windows.Forms.Button();
            this.btnAudio2 = new System.Windows.Forms.Button();
            this.btnElectrocasnice2 = new System.Windows.Forms.Button();
            this.btnLaptop2 = new System.Windows.Forms.Button();
            this.btnDesktop2 = new System.Windows.Forms.Button();
            this.pnlOferta = new System.Windows.Forms.Panel();
            this.btnSmartphone2 = new System.Windows.Forms.Button();
            this.btnTelevizor2 = new System.Windows.Forms.Button();
            this.pnlTopBar = new System.Windows.Forms.Panel();
            this.lstPreturi = new System.Windows.Forms.ListBox();
            this.pnlCos = new System.Windows.Forms.Panel();
            this.btnStergElem = new System.Windows.Forms.Button();
            this.btnGolCos = new System.Windows.Forms.Button();
            this.btnComanda = new System.Windows.Forms.Button();
            this.lstCos = new System.Windows.Forms.ListBox();
            this.btnBack = new System.Windows.Forms.Button();
            this.lblValCos = new System.Windows.Forms.Label();
            this.btnCos = new System.Windows.Forms.Button();
            this.pnlMain.SuspendLayout();
            this.tblTelefoane.SuspendLayout();
            this.panel11.SuspendLayout();
            this.panel10.SuspendLayout();
            this.panel9.SuspendLayout();
            this.panel8.SuspendLayout();
            this.panel7.SuspendLayout();
            this.panel6.SuspendLayout();
            this.panel5.SuspendLayout();
            this.panel4.SuspendLayout();
            this.panel3.SuspendLayout();
            this.panel2.SuspendLayout();
            this.panel1.SuspendLayout();
            this.pnlElementTelefoane.SuspendLayout();
            this.tblOferta.SuspendLayout();
            this.pnlOferta.SuspendLayout();
            this.pnlTopBar.SuspendLayout();
            this.pnlCos.SuspendLayout();
            this.SuspendLayout();
            // 
            // pnlMain
            // 
            this.pnlMain.AutoScroll = true;
            this.pnlMain.AutoScrollMargin = new System.Drawing.Size(10, 10);
            this.pnlMain.BackColor = System.Drawing.Color.White;
            this.pnlMain.Controls.Add(this.tblTelefoane);
            this.pnlMain.Controls.Add(this.tblOferta);
            this.pnlMain.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pnlMain.Location = new System.Drawing.Point(0, 63);
            this.pnlMain.Name = "pnlMain";
            this.pnlMain.Size = new System.Drawing.Size(965, 723);
            this.pnlMain.TabIndex = 1;
            // 
            // tblTelefoane
            // 
            this.tblTelefoane.ColumnCount = 3;
            this.tblTelefoane.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 33.40437F));
            this.tblTelefoane.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 33.40319F));
            this.tblTelefoane.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 33.19244F));
            this.tblTelefoane.Controls.Add(this.panel11, 2, 3);
            this.tblTelefoane.Controls.Add(this.panel10, 1, 3);
            this.tblTelefoane.Controls.Add(this.panel9, 0, 3);
            this.tblTelefoane.Controls.Add(this.panel8, 2, 2);
            this.tblTelefoane.Controls.Add(this.panel7, 1, 2);
            this.tblTelefoane.Controls.Add(this.panel6, 0, 2);
            this.tblTelefoane.Controls.Add(this.panel5, 2, 1);
            this.tblTelefoane.Controls.Add(this.panel4, 1, 1);
            this.tblTelefoane.Controls.Add(this.panel3, 0, 1);
            this.tblTelefoane.Controls.Add(this.panel2, 2, 0);
            this.tblTelefoane.Controls.Add(this.panel1, 1, 0);
            this.tblTelefoane.Controls.Add(this.pnlElementTelefoane, 0, 0);
            this.tblTelefoane.Dock = System.Windows.Forms.DockStyle.Top;
            this.tblTelefoane.Location = new System.Drawing.Point(0, 747);
            this.tblTelefoane.Name = "tblTelefoane";
            this.tblTelefoane.RowCount = 4;
            this.tblTelefoane.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 25F));
            this.tblTelefoane.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 25F));
            this.tblTelefoane.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 25F));
            this.tblTelefoane.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 25F));
            this.tblTelefoane.Size = new System.Drawing.Size(948, 1220);
            this.tblTelefoane.TabIndex = 2;
            this.tblTelefoane.Visible = false;
            // 
            // panel11
            // 
            this.panel11.Controls.Add(this.button21);
            this.panel11.Controls.Add(this.button22);
            this.panel11.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel11.Location = new System.Drawing.Point(635, 918);
            this.panel11.Name = "panel11";
            this.panel11.Size = new System.Drawing.Size(310, 299);
            this.panel11.TabIndex = 11;
            // 
            // button21
            // 
            this.button21.BackgroundImage = global::Magazin.ResourcesSmartphone.Iphone_SE;
            this.button21.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.button21.Dock = System.Windows.Forms.DockStyle.Fill;
            this.button21.FlatAppearance.BorderSize = 0;
            this.button21.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button21.Font = new System.Drawing.Font("Segoe UI", 20.25F, System.Drawing.FontStyle.Bold);
            this.button21.ForeColor = System.Drawing.Color.Red;
            this.button21.Location = new System.Drawing.Point(0, 0);
            this.button21.Margin = new System.Windows.Forms.Padding(0);
            this.button21.Name = "button21";
            this.button21.Size = new System.Drawing.Size(310, 263);
            this.button21.TabIndex = 1;
            this.button21.Text = "1900 Ron";
            this.button21.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.button21.UseVisualStyleBackColor = true;
            // 
            // button22
            // 
            this.button22.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.button22.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.button22.FlatAppearance.BorderSize = 0;
            this.button22.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button22.Font = new System.Drawing.Font("Arial", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button22.ForeColor = System.Drawing.Color.White;
            this.button22.Location = new System.Drawing.Point(0, 263);
            this.button22.Margin = new System.Windows.Forms.Padding(0);
            this.button22.Name = "button22";
            this.button22.Size = new System.Drawing.Size(310, 36);
            this.button22.TabIndex = 0;
            this.button22.Text = "Adauga In Cos";
            this.button22.UseVisualStyleBackColor = false;
            // 
            // panel10
            // 
            this.panel10.Controls.Add(this.button19);
            this.panel10.Controls.Add(this.button20);
            this.panel10.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel10.Location = new System.Drawing.Point(319, 918);
            this.panel10.Name = "panel10";
            this.panel10.Size = new System.Drawing.Size(310, 299);
            this.panel10.TabIndex = 10;
            // 
            // button19
            // 
            this.button19.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("button19.BackgroundImage")));
            this.button19.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.button19.Dock = System.Windows.Forms.DockStyle.Fill;
            this.button19.FlatAppearance.BorderSize = 0;
            this.button19.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button19.Font = new System.Drawing.Font("Segoe UI", 20.25F, System.Drawing.FontStyle.Bold);
            this.button19.ForeColor = System.Drawing.Color.Red;
            this.button19.Location = new System.Drawing.Point(0, 0);
            this.button19.Margin = new System.Windows.Forms.Padding(0);
            this.button19.Name = "button19";
            this.button19.Size = new System.Drawing.Size(310, 263);
            this.button19.TabIndex = 1;
            this.button19.Text = "5000 Ron";
            this.button19.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.button19.UseVisualStyleBackColor = true;
            // 
            // button20
            // 
            this.button20.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.button20.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.button20.FlatAppearance.BorderSize = 0;
            this.button20.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button20.Font = new System.Drawing.Font("Arial", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button20.ForeColor = System.Drawing.Color.White;
            this.button20.Location = new System.Drawing.Point(0, 263);
            this.button20.Margin = new System.Windows.Forms.Padding(0);
            this.button20.Name = "button20";
            this.button20.Size = new System.Drawing.Size(310, 36);
            this.button20.TabIndex = 0;
            this.button20.Text = "Adauga In Cos";
            this.button20.UseVisualStyleBackColor = false;
            // 
            // panel9
            // 
            this.panel9.Controls.Add(this.button17);
            this.panel9.Controls.Add(this.button18);
            this.panel9.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel9.Location = new System.Drawing.Point(3, 918);
            this.panel9.Name = "panel9";
            this.panel9.Size = new System.Drawing.Size(310, 299);
            this.panel9.TabIndex = 9;
            // 
            // button17
            // 
            this.button17.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("button17.BackgroundImage")));
            this.button17.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.button17.Dock = System.Windows.Forms.DockStyle.Fill;
            this.button17.FlatAppearance.BorderSize = 0;
            this.button17.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button17.Font = new System.Drawing.Font("Segoe UI", 20.25F, System.Drawing.FontStyle.Bold);
            this.button17.ForeColor = System.Drawing.Color.Red;
            this.button17.Location = new System.Drawing.Point(0, 0);
            this.button17.Margin = new System.Windows.Forms.Padding(0);
            this.button17.Name = "button17";
            this.button17.Size = new System.Drawing.Size(310, 263);
            this.button17.TabIndex = 1;
            this.button17.Text = "2700 Ron";
            this.button17.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.button17.UseVisualStyleBackColor = true;
            // 
            // button18
            // 
            this.button18.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.button18.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.button18.FlatAppearance.BorderSize = 0;
            this.button18.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button18.Font = new System.Drawing.Font("Arial", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button18.ForeColor = System.Drawing.Color.White;
            this.button18.Location = new System.Drawing.Point(0, 263);
            this.button18.Margin = new System.Windows.Forms.Padding(0);
            this.button18.Name = "button18";
            this.button18.Size = new System.Drawing.Size(310, 36);
            this.button18.TabIndex = 0;
            this.button18.Text = "Adauga In Cos";
            this.button18.UseVisualStyleBackColor = false;
            // 
            // panel8
            // 
            this.panel8.Controls.Add(this.button15);
            this.panel8.Controls.Add(this.button16);
            this.panel8.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel8.Location = new System.Drawing.Point(635, 613);
            this.panel8.Name = "panel8";
            this.panel8.Size = new System.Drawing.Size(310, 299);
            this.panel8.TabIndex = 8;
            // 
            // button15
            // 
            this.button15.BackgroundImage = global::Magazin.ResourcesSmartphone.Motorolla_Razr;
            this.button15.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.button15.Dock = System.Windows.Forms.DockStyle.Fill;
            this.button15.FlatAppearance.BorderSize = 0;
            this.button15.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button15.Font = new System.Drawing.Font("Segoe UI", 20.25F, System.Drawing.FontStyle.Bold);
            this.button15.ForeColor = System.Drawing.Color.Red;
            this.button15.Location = new System.Drawing.Point(0, 0);
            this.button15.Margin = new System.Windows.Forms.Padding(0);
            this.button15.Name = "button15";
            this.button15.Size = new System.Drawing.Size(310, 263);
            this.button15.TabIndex = 1;
            this.button15.Text = "4000 Ron";
            this.button15.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.button15.UseVisualStyleBackColor = true;
            // 
            // button16
            // 
            this.button16.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.button16.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.button16.FlatAppearance.BorderSize = 0;
            this.button16.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button16.Font = new System.Drawing.Font("Arial", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button16.ForeColor = System.Drawing.Color.White;
            this.button16.Location = new System.Drawing.Point(0, 263);
            this.button16.Margin = new System.Windows.Forms.Padding(0);
            this.button16.Name = "button16";
            this.button16.Size = new System.Drawing.Size(310, 36);
            this.button16.TabIndex = 0;
            this.button16.Text = "Adauga In Cos";
            this.button16.UseVisualStyleBackColor = false;
            // 
            // panel7
            // 
            this.panel7.Controls.Add(this.button13);
            this.panel7.Controls.Add(this.button14);
            this.panel7.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel7.Location = new System.Drawing.Point(319, 613);
            this.panel7.Name = "panel7";
            this.panel7.Size = new System.Drawing.Size(310, 299);
            this.panel7.TabIndex = 7;
            // 
            // button13
            // 
            this.button13.BackgroundImage = global::Magazin.ResourcesSmartphone.Nokia_9;
            this.button13.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.button13.Dock = System.Windows.Forms.DockStyle.Fill;
            this.button13.FlatAppearance.BorderSize = 0;
            this.button13.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button13.Font = new System.Drawing.Font("Segoe UI", 20.25F, System.Drawing.FontStyle.Bold);
            this.button13.ForeColor = System.Drawing.Color.Red;
            this.button13.Location = new System.Drawing.Point(0, 0);
            this.button13.Margin = new System.Windows.Forms.Padding(0);
            this.button13.Name = "button13";
            this.button13.Size = new System.Drawing.Size(310, 263);
            this.button13.TabIndex = 1;
            this.button13.Text = "2800 Ron";
            this.button13.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.button13.UseVisualStyleBackColor = true;
            // 
            // button14
            // 
            this.button14.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.button14.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.button14.FlatAppearance.BorderSize = 0;
            this.button14.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button14.Font = new System.Drawing.Font("Arial", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button14.ForeColor = System.Drawing.Color.White;
            this.button14.Location = new System.Drawing.Point(0, 263);
            this.button14.Margin = new System.Windows.Forms.Padding(0);
            this.button14.Name = "button14";
            this.button14.Size = new System.Drawing.Size(310, 36);
            this.button14.TabIndex = 0;
            this.button14.Text = "Adauga In Cos";
            this.button14.UseVisualStyleBackColor = false;
            // 
            // panel6
            // 
            this.panel6.Controls.Add(this.button11);
            this.panel6.Controls.Add(this.button12);
            this.panel6.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel6.Location = new System.Drawing.Point(3, 613);
            this.panel6.Name = "panel6";
            this.panel6.Size = new System.Drawing.Size(310, 299);
            this.panel6.TabIndex = 6;
            // 
            // button11
            // 
            this.button11.BackgroundImage = global::Magazin.ResourcesSmartphone.samsung_note_20;
            this.button11.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.button11.Dock = System.Windows.Forms.DockStyle.Fill;
            this.button11.FlatAppearance.BorderSize = 0;
            this.button11.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button11.Font = new System.Drawing.Font("Segoe UI", 20.25F, System.Drawing.FontStyle.Bold);
            this.button11.ForeColor = System.Drawing.Color.Red;
            this.button11.Location = new System.Drawing.Point(0, 0);
            this.button11.Margin = new System.Windows.Forms.Padding(0);
            this.button11.Name = "button11";
            this.button11.Size = new System.Drawing.Size(310, 263);
            this.button11.TabIndex = 1;
            this.button11.Text = "7000 Ron";
            this.button11.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.button11.UseVisualStyleBackColor = true;
            // 
            // button12
            // 
            this.button12.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.button12.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.button12.FlatAppearance.BorderSize = 0;
            this.button12.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button12.Font = new System.Drawing.Font("Arial", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button12.ForeColor = System.Drawing.Color.White;
            this.button12.Location = new System.Drawing.Point(0, 263);
            this.button12.Margin = new System.Windows.Forms.Padding(0);
            this.button12.Name = "button12";
            this.button12.Size = new System.Drawing.Size(310, 36);
            this.button12.TabIndex = 0;
            this.button12.Text = "Adauga In Cos";
            this.button12.UseVisualStyleBackColor = false;
            // 
            // panel5
            // 
            this.panel5.Controls.Add(this.button9);
            this.panel5.Controls.Add(this.button10);
            this.panel5.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel5.Location = new System.Drawing.Point(635, 308);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(310, 299);
            this.panel5.TabIndex = 5;
            // 
            // button9
            // 
            this.button9.BackgroundImage = global::Magazin.ResourcesSmartphone.Oppo_F17_Pro;
            this.button9.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.button9.Dock = System.Windows.Forms.DockStyle.Fill;
            this.button9.FlatAppearance.BorderSize = 0;
            this.button9.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button9.Font = new System.Drawing.Font("Segoe UI", 20.25F, System.Drawing.FontStyle.Bold);
            this.button9.ForeColor = System.Drawing.Color.Red;
            this.button9.Location = new System.Drawing.Point(0, 0);
            this.button9.Margin = new System.Windows.Forms.Padding(0);
            this.button9.Name = "button9";
            this.button9.Size = new System.Drawing.Size(310, 263);
            this.button9.TabIndex = 1;
            this.button9.Text = "2500 Ron";
            this.button9.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.button9.UseVisualStyleBackColor = true;
            // 
            // button10
            // 
            this.button10.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.button10.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.button10.FlatAppearance.BorderSize = 0;
            this.button10.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button10.Font = new System.Drawing.Font("Arial", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button10.ForeColor = System.Drawing.Color.White;
            this.button10.Location = new System.Drawing.Point(0, 263);
            this.button10.Margin = new System.Windows.Forms.Padding(0);
            this.button10.Name = "button10";
            this.button10.Size = new System.Drawing.Size(310, 36);
            this.button10.TabIndex = 0;
            this.button10.Text = "Adauga In Cos";
            this.button10.UseVisualStyleBackColor = false;
            // 
            // panel4
            // 
            this.panel4.Controls.Add(this.button7);
            this.panel4.Controls.Add(this.button8);
            this.panel4.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel4.Location = new System.Drawing.Point(319, 308);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(310, 299);
            this.panel4.TabIndex = 4;
            // 
            // button7
            // 
            this.button7.BackgroundImage = global::Magazin.ResourcesSmartphone.Oneplus_8;
            this.button7.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.button7.Dock = System.Windows.Forms.DockStyle.Fill;
            this.button7.FlatAppearance.BorderSize = 0;
            this.button7.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button7.Font = new System.Drawing.Font("Segoe UI", 20.25F, System.Drawing.FontStyle.Bold);
            this.button7.ForeColor = System.Drawing.Color.Red;
            this.button7.Location = new System.Drawing.Point(0, 0);
            this.button7.Margin = new System.Windows.Forms.Padding(0);
            this.button7.Name = "button7";
            this.button7.Size = new System.Drawing.Size(310, 263);
            this.button7.TabIndex = 1;
            this.button7.Text = "3500 Ron";
            this.button7.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.button7.UseVisualStyleBackColor = true;
            // 
            // button8
            // 
            this.button8.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.button8.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.button8.FlatAppearance.BorderSize = 0;
            this.button8.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button8.Font = new System.Drawing.Font("Arial", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button8.ForeColor = System.Drawing.Color.White;
            this.button8.Location = new System.Drawing.Point(0, 263);
            this.button8.Margin = new System.Windows.Forms.Padding(0);
            this.button8.Name = "button8";
            this.button8.Size = new System.Drawing.Size(310, 36);
            this.button8.TabIndex = 0;
            this.button8.Text = "Adauga In Cos";
            this.button8.UseVisualStyleBackColor = false;
            // 
            // panel3
            // 
            this.panel3.Controls.Add(this.button5);
            this.panel3.Controls.Add(this.button6);
            this.panel3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel3.Location = new System.Drawing.Point(3, 308);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(310, 299);
            this.panel3.TabIndex = 3;
            // 
            // button5
            // 
            this.button5.BackgroundImage = global::Magazin.ResourcesSmartphone.Xiaomi_Mi_11;
            this.button5.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.button5.Dock = System.Windows.Forms.DockStyle.Fill;
            this.button5.FlatAppearance.BorderSize = 0;
            this.button5.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button5.Font = new System.Drawing.Font("Segoe UI", 20.25F, System.Drawing.FontStyle.Bold);
            this.button5.ForeColor = System.Drawing.Color.Red;
            this.button5.Location = new System.Drawing.Point(0, 0);
            this.button5.Margin = new System.Windows.Forms.Padding(0);
            this.button5.Name = "button5";
            this.button5.Size = new System.Drawing.Size(310, 263);
            this.button5.TabIndex = 1;
            this.button5.Text = "4000 Ron";
            this.button5.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.button5.UseVisualStyleBackColor = true;
            // 
            // button6
            // 
            this.button6.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.button6.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.button6.FlatAppearance.BorderSize = 0;
            this.button6.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button6.Font = new System.Drawing.Font("Arial", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button6.ForeColor = System.Drawing.Color.White;
            this.button6.Location = new System.Drawing.Point(0, 263);
            this.button6.Margin = new System.Windows.Forms.Padding(0);
            this.button6.Name = "button6";
            this.button6.Size = new System.Drawing.Size(310, 36);
            this.button6.TabIndex = 0;
            this.button6.Text = "Adauga In Cos";
            this.button6.UseVisualStyleBackColor = false;
            // 
            // panel2
            // 
            this.panel2.Controls.Add(this.button3);
            this.panel2.Controls.Add(this.button4);
            this.panel2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel2.Location = new System.Drawing.Point(635, 3);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(310, 299);
            this.panel2.TabIndex = 2;
            // 
            // button3
            // 
            this.button3.BackgroundImage = global::Magazin.ResourcesSmartphone.Iphone_12_Pro_Max;
            this.button3.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.button3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.button3.FlatAppearance.BorderSize = 0;
            this.button3.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button3.Font = new System.Drawing.Font("Segoe UI", 20.25F, System.Drawing.FontStyle.Bold);
            this.button3.ForeColor = System.Drawing.Color.Red;
            this.button3.Location = new System.Drawing.Point(0, 0);
            this.button3.Margin = new System.Windows.Forms.Padding(0);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(310, 263);
            this.button3.TabIndex = 1;
            this.button3.Text = "6000 Ron";
            this.button3.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.button3.UseVisualStyleBackColor = true;
            // 
            // button4
            // 
            this.button4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.button4.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.button4.FlatAppearance.BorderSize = 0;
            this.button4.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button4.Font = new System.Drawing.Font("Arial", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button4.ForeColor = System.Drawing.Color.White;
            this.button4.Location = new System.Drawing.Point(0, 263);
            this.button4.Margin = new System.Windows.Forms.Padding(0);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(310, 36);
            this.button4.TabIndex = 0;
            this.button4.Text = "Adauga In Cos";
            this.button4.UseVisualStyleBackColor = false;
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.button1);
            this.panel1.Controls.Add(this.button2);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel1.Location = new System.Drawing.Point(319, 3);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(310, 299);
            this.panel1.TabIndex = 1;
            // 
            // button1
            // 
            this.button1.BackgroundImage = global::Magazin.ResourcesSmartphone.Huawei_P40_Lite_E;
            this.button1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.button1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.button1.FlatAppearance.BorderSize = 0;
            this.button1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button1.Font = new System.Drawing.Font("Segoe UI", 20.25F, System.Drawing.FontStyle.Bold);
            this.button1.ForeColor = System.Drawing.Color.Red;
            this.button1.Location = new System.Drawing.Point(0, 0);
            this.button1.Margin = new System.Windows.Forms.Padding(0);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(310, 263);
            this.button1.TabIndex = 1;
            this.button1.Text = "3000 Ron";
            this.button1.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.button1.UseVisualStyleBackColor = true;
            // 
            // button2
            // 
            this.button2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.button2.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.button2.FlatAppearance.BorderSize = 0;
            this.button2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button2.Font = new System.Drawing.Font("Arial", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button2.ForeColor = System.Drawing.Color.White;
            this.button2.Location = new System.Drawing.Point(0, 263);
            this.button2.Margin = new System.Windows.Forms.Padding(0);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(310, 36);
            this.button2.TabIndex = 0;
            this.button2.Text = "Adauga In Cos";
            this.button2.UseVisualStyleBackColor = false;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // pnlElementTelefoane
            // 
            this.pnlElementTelefoane.Controls.Add(this.btnPagElem1);
            this.pnlElementTelefoane.Controls.Add(this.btnCosTel1);
            this.pnlElementTelefoane.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pnlElementTelefoane.Location = new System.Drawing.Point(3, 3);
            this.pnlElementTelefoane.Name = "pnlElementTelefoane";
            this.pnlElementTelefoane.Size = new System.Drawing.Size(310, 299);
            this.pnlElementTelefoane.TabIndex = 0;
            // 
            // btnPagElem1
            // 
            this.btnPagElem1.BackgroundImage = global::Magazin.ResourcesSmartphone.Samsung_Galaxy_S21;
            this.btnPagElem1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.btnPagElem1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.btnPagElem1.FlatAppearance.BorderSize = 0;
            this.btnPagElem1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnPagElem1.Font = new System.Drawing.Font("Segoe UI", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnPagElem1.ForeColor = System.Drawing.Color.Red;
            this.btnPagElem1.Location = new System.Drawing.Point(0, 0);
            this.btnPagElem1.Margin = new System.Windows.Forms.Padding(0);
            this.btnPagElem1.Name = "btnPagElem1";
            this.btnPagElem1.Size = new System.Drawing.Size(310, 263);
            this.btnPagElem1.TabIndex = 1;
            this.btnPagElem1.Text = "5000 Ron\r\n";
            this.btnPagElem1.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.btnPagElem1.UseVisualStyleBackColor = true;
            // 
            // btnCosTel1
            // 
            this.btnCosTel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.btnCosTel1.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.btnCosTel1.FlatAppearance.BorderSize = 0;
            this.btnCosTel1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnCosTel1.Font = new System.Drawing.Font("Arial", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCosTel1.ForeColor = System.Drawing.Color.White;
            this.btnCosTel1.Location = new System.Drawing.Point(0, 263);
            this.btnCosTel1.Margin = new System.Windows.Forms.Padding(0);
            this.btnCosTel1.Name = "btnCosTel1";
            this.btnCosTel1.Size = new System.Drawing.Size(310, 36);
            this.btnCosTel1.TabIndex = 0;
            this.btnCosTel1.Text = "Adauga In Cos";
            this.btnCosTel1.UseVisualStyleBackColor = false;
            this.btnCosTel1.Click += new System.EventHandler(this.btnCosTel1_Click);
            // 
            // tblOferta
            // 
            this.tblOferta.AutoScrollMargin = new System.Drawing.Size(100, 100);
            this.tblOferta.BackColor = System.Drawing.Color.LightGray;
            this.tblOferta.ColumnCount = 3;
            this.tblOferta.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 33.33333F));
            this.tblOferta.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 33.33334F));
            this.tblOferta.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 33.33334F));
            this.tblOferta.Controls.Add(this.btnWearables2, 2, 2);
            this.tblOferta.Controls.Add(this.btnFoto2, 1, 2);
            this.tblOferta.Controls.Add(this.btnConsole2, 0, 2);
            this.tblOferta.Controls.Add(this.btnAudio2, 2, 1);
            this.tblOferta.Controls.Add(this.btnElectrocasnice2, 1, 1);
            this.tblOferta.Controls.Add(this.btnLaptop2, 2, 0);
            this.tblOferta.Controls.Add(this.btnDesktop2, 0, 1);
            this.tblOferta.Controls.Add(this.pnlOferta, 0, 0);
            this.tblOferta.Controls.Add(this.btnTelevizor2, 1, 0);
            this.tblOferta.Dock = System.Windows.Forms.DockStyle.Top;
            this.tblOferta.Location = new System.Drawing.Point(0, 0);
            this.tblOferta.MinimumSize = new System.Drawing.Size(246, 745);
            this.tblOferta.Name = "tblOferta";
            this.tblOferta.RowCount = 3;
            this.tblOferta.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 33.33332F));
            this.tblOferta.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 33.33334F));
            this.tblOferta.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 33.33334F));
            this.tblOferta.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tblOferta.Size = new System.Drawing.Size(948, 747);
            this.tblOferta.TabIndex = 1;
            this.tblOferta.Paint += new System.Windows.Forms.PaintEventHandler(this.tblOferta_Paint);
            // 
            // btnWearables2
            // 
            this.btnWearables2.BackColor = System.Drawing.Color.White;
            this.btnWearables2.BackgroundImage = global::Magazin.ResourcesSmartphone.Wearables;
            this.btnWearables2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.btnWearables2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.btnWearables2.Font = new System.Drawing.Font("Microsoft Sans Serif", 27F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnWearables2.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.btnWearables2.Location = new System.Drawing.Point(634, 500);
            this.btnWearables2.MinimumSize = new System.Drawing.Size(150, 0);
            this.btnWearables2.Name = "btnWearables2";
            this.btnWearables2.Size = new System.Drawing.Size(311, 244);
            this.btnWearables2.TabIndex = 17;
            this.btnWearables2.Text = "Wearables";
            this.btnWearables2.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.btnWearables2.UseVisualStyleBackColor = false;
            // 
            // btnFoto2
            // 
            this.btnFoto2.BackColor = System.Drawing.Color.White;
            this.btnFoto2.BackgroundImage = global::Magazin.ResourcesSmartphone.Foto;
            this.btnFoto2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.btnFoto2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.btnFoto2.Font = new System.Drawing.Font("Microsoft Sans Serif", 27F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnFoto2.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.btnFoto2.Location = new System.Drawing.Point(318, 500);
            this.btnFoto2.MinimumSize = new System.Drawing.Size(150, 0);
            this.btnFoto2.Name = "btnFoto2";
            this.btnFoto2.Size = new System.Drawing.Size(310, 244);
            this.btnFoto2.TabIndex = 16;
            this.btnFoto2.Text = "Foto";
            this.btnFoto2.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.btnFoto2.UseVisualStyleBackColor = false;
            // 
            // btnConsole2
            // 
            this.btnConsole2.BackColor = System.Drawing.Color.White;
            this.btnConsole2.BackgroundImage = global::Magazin.ResourcesSmartphone.Gaming_Consoles;
            this.btnConsole2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.btnConsole2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.btnConsole2.Font = new System.Drawing.Font("Microsoft Sans Serif", 21.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnConsole2.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.btnConsole2.Location = new System.Drawing.Point(3, 500);
            this.btnConsole2.MinimumSize = new System.Drawing.Size(150, 0);
            this.btnConsole2.Name = "btnConsole2";
            this.btnConsole2.Size = new System.Drawing.Size(309, 244);
            this.btnConsole2.TabIndex = 15;
            this.btnConsole2.Text = "Console Jocuri";
            this.btnConsole2.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.btnConsole2.UseVisualStyleBackColor = false;
            // 
            // btnAudio2
            // 
            this.btnAudio2.BackColor = System.Drawing.Color.White;
            this.btnAudio2.BackgroundImage = global::Magazin.ResourcesSmartphone.Audio;
            this.btnAudio2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.btnAudio2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.btnAudio2.Font = new System.Drawing.Font("Microsoft Sans Serif", 27F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnAudio2.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.btnAudio2.Location = new System.Drawing.Point(634, 251);
            this.btnAudio2.MinimumSize = new System.Drawing.Size(150, 0);
            this.btnAudio2.Name = "btnAudio2";
            this.btnAudio2.Size = new System.Drawing.Size(311, 243);
            this.btnAudio2.TabIndex = 14;
            this.btnAudio2.Text = "Audio";
            this.btnAudio2.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.btnAudio2.UseVisualStyleBackColor = false;
            // 
            // btnElectrocasnice2
            // 
            this.btnElectrocasnice2.BackColor = System.Drawing.Color.White;
            this.btnElectrocasnice2.BackgroundImage = global::Magazin.ResourcesSmartphone.electrocasnice;
            this.btnElectrocasnice2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.btnElectrocasnice2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.btnElectrocasnice2.Font = new System.Drawing.Font("Microsoft Sans Serif", 24F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnElectrocasnice2.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.btnElectrocasnice2.Location = new System.Drawing.Point(318, 251);
            this.btnElectrocasnice2.MinimumSize = new System.Drawing.Size(150, 0);
            this.btnElectrocasnice2.Name = "btnElectrocasnice2";
            this.btnElectrocasnice2.Size = new System.Drawing.Size(310, 243);
            this.btnElectrocasnice2.TabIndex = 13;
            this.btnElectrocasnice2.Text = "Electrocasnice";
            this.btnElectrocasnice2.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.btnElectrocasnice2.UseVisualStyleBackColor = false;
            // 
            // btnLaptop2
            // 
            this.btnLaptop2.BackColor = System.Drawing.Color.White;
            this.btnLaptop2.BackgroundImage = global::Magazin.ResourcesSmartphone.Laptop;
            this.btnLaptop2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.btnLaptop2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.btnLaptop2.Font = new System.Drawing.Font("Microsoft Sans Serif", 27F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnLaptop2.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.btnLaptop2.Location = new System.Drawing.Point(634, 3);
            this.btnLaptop2.MinimumSize = new System.Drawing.Size(150, 0);
            this.btnLaptop2.Name = "btnLaptop2";
            this.btnLaptop2.Size = new System.Drawing.Size(311, 242);
            this.btnLaptop2.TabIndex = 12;
            this.btnLaptop2.Text = "Laptop";
            this.btnLaptop2.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.btnLaptop2.UseVisualStyleBackColor = false;
            // 
            // btnDesktop2
            // 
            this.btnDesktop2.BackColor = System.Drawing.Color.White;
            this.btnDesktop2.BackgroundImage = global::Magazin.ResourcesSmartphone.Desktop;
            this.btnDesktop2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.btnDesktop2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.btnDesktop2.Font = new System.Drawing.Font("Microsoft Sans Serif", 27F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnDesktop2.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.btnDesktop2.Location = new System.Drawing.Point(3, 251);
            this.btnDesktop2.MinimumSize = new System.Drawing.Size(150, 0);
            this.btnDesktop2.Name = "btnDesktop2";
            this.btnDesktop2.Size = new System.Drawing.Size(309, 243);
            this.btnDesktop2.TabIndex = 11;
            this.btnDesktop2.Text = "Desktop";
            this.btnDesktop2.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.btnDesktop2.UseVisualStyleBackColor = false;
            // 
            // pnlOferta
            // 
            this.pnlOferta.AutoScrollMargin = new System.Drawing.Size(10, 10);
            this.pnlOferta.Controls.Add(this.btnSmartphone2);
            this.pnlOferta.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pnlOferta.Location = new System.Drawing.Point(2, 2);
            this.pnlOferta.Margin = new System.Windows.Forms.Padding(2);
            this.pnlOferta.Name = "pnlOferta";
            this.pnlOferta.Size = new System.Drawing.Size(311, 244);
            this.pnlOferta.TabIndex = 0;
            // 
            // btnSmartphone2
            // 
            this.btnSmartphone2.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.btnSmartphone2.BackColor = System.Drawing.Color.White;
            this.btnSmartphone2.BackgroundImage = global::Magazin.ResourcesSmartphone.Iphone_12_Pro_Max;
            this.btnSmartphone2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.btnSmartphone2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.btnSmartphone2.Font = new System.Drawing.Font("Microsoft Sans Serif", 27.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSmartphone2.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.btnSmartphone2.Location = new System.Drawing.Point(0, 0);
            this.btnSmartphone2.MinimumSize = new System.Drawing.Size(150, 0);
            this.btnSmartphone2.Name = "btnSmartphone2";
            this.btnSmartphone2.Size = new System.Drawing.Size(311, 244);
            this.btnSmartphone2.TabIndex = 0;
            this.btnSmartphone2.Text = "Smartphone";
            this.btnSmartphone2.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.btnSmartphone2.UseVisualStyleBackColor = false;
            this.btnSmartphone2.Click += new System.EventHandler(this.btnSmartphone2_Click);
            // 
            // btnTelevizor2
            // 
            this.btnTelevizor2.BackColor = System.Drawing.Color.White;
            this.btnTelevizor2.BackgroundImage = global::Magazin.ResourcesSmartphone.Televizoare;
            this.btnTelevizor2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.btnTelevizor2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.btnTelevizor2.Font = new System.Drawing.Font("Microsoft Sans Serif", 27F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnTelevizor2.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.btnTelevizor2.Location = new System.Drawing.Point(318, 3);
            this.btnTelevizor2.MinimumSize = new System.Drawing.Size(150, 0);
            this.btnTelevizor2.Name = "btnTelevizor2";
            this.btnTelevizor2.Size = new System.Drawing.Size(310, 242);
            this.btnTelevizor2.TabIndex = 9;
            this.btnTelevizor2.Text = "Televizoare";
            this.btnTelevizor2.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.btnTelevizor2.UseVisualStyleBackColor = false;
            this.btnTelevizor2.Click += new System.EventHandler(this.btnTelevizor2_Click);
            // 
            // pnlTopBar
            // 
            this.pnlTopBar.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.pnlTopBar.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(239)))), ((int)(((byte)(131)))), ((int)(((byte)(84)))));
            this.pnlTopBar.Controls.Add(this.lstPreturi);
            this.pnlTopBar.Controls.Add(this.pnlCos);
            this.pnlTopBar.Controls.Add(this.btnBack);
            this.pnlTopBar.Controls.Add(this.lblValCos);
            this.pnlTopBar.Controls.Add(this.btnCos);
            this.pnlTopBar.Dock = System.Windows.Forms.DockStyle.Top;
            this.pnlTopBar.Location = new System.Drawing.Point(0, 0);
            this.pnlTopBar.Name = "pnlTopBar";
            this.pnlTopBar.Size = new System.Drawing.Size(965, 63);
            this.pnlTopBar.TabIndex = 0;
            // 
            // lstPreturi
            // 
            this.lstPreturi.FormattingEnabled = true;
            this.lstPreturi.Location = new System.Drawing.Point(731, 264);
            this.lstPreturi.Name = "lstPreturi";
            this.lstPreturi.Size = new System.Drawing.Size(120, 95);
            this.lstPreturi.TabIndex = 4;
            this.lstPreturi.Visible = false;
            // 
            // pnlCos
            // 
            this.pnlCos.Controls.Add(this.btnStergElem);
            this.pnlCos.Controls.Add(this.btnGolCos);
            this.pnlCos.Controls.Add(this.btnComanda);
            this.pnlCos.Controls.Add(this.lstCos);
            this.pnlCos.Dock = System.Windows.Forms.DockStyle.Left;
            this.pnlCos.Location = new System.Drawing.Point(71, 0);
            this.pnlCos.Name = "pnlCos";
            this.pnlCos.Size = new System.Drawing.Size(558, 63);
            this.pnlCos.TabIndex = 3;
            this.pnlCos.Visible = false;
            // 
            // btnStergElem
            // 
            this.btnStergElem.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.btnStergElem.FlatAppearance.BorderSize = 0;
            this.btnStergElem.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnStergElem.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnStergElem.Location = new System.Drawing.Point(361, 3);
            this.btnStergElem.Name = "btnStergElem";
            this.btnStergElem.Size = new System.Drawing.Size(197, 30);
            this.btnStergElem.TabIndex = 3;
            this.btnStergElem.Text = "Elimina din Cos";
            this.btnStergElem.UseVisualStyleBackColor = true;
            this.btnStergElem.Visible = false;
            this.btnStergElem.Click += new System.EventHandler(this.btnStergElem_Click);
            // 
            // btnGolCos
            // 
            this.btnGolCos.Dock = System.Windows.Forms.DockStyle.Top;
            this.btnGolCos.FlatAppearance.BorderSize = 0;
            this.btnGolCos.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnGolCos.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnGolCos.Location = new System.Drawing.Point(361, 0);
            this.btnGolCos.Name = "btnGolCos";
            this.btnGolCos.Size = new System.Drawing.Size(197, 30);
            this.btnGolCos.TabIndex = 2;
            this.btnGolCos.Text = "Goleste Cosul";
            this.btnGolCos.UseVisualStyleBackColor = true;
            this.btnGolCos.Click += new System.EventHandler(this.btnGolCos_Click);
            // 
            // btnComanda
            // 
            this.btnComanda.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.btnComanda.FlatAppearance.BorderSize = 0;
            this.btnComanda.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnComanda.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnComanda.Location = new System.Drawing.Point(361, 33);
            this.btnComanda.Name = "btnComanda";
            this.btnComanda.Size = new System.Drawing.Size(197, 30);
            this.btnComanda.TabIndex = 1;
            this.btnComanda.Text = "Comanda";
            this.btnComanda.UseVisualStyleBackColor = true;
            this.btnComanda.Visible = false;
            // 
            // lstCos
            // 
            this.lstCos.Dock = System.Windows.Forms.DockStyle.Left;
            this.lstCos.Font = new System.Drawing.Font("Segoe UI", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lstCos.FormattingEnabled = true;
            this.lstCos.ItemHeight = 30;
            this.lstCos.Location = new System.Drawing.Point(0, 0);
            this.lstCos.Name = "lstCos";
            this.lstCos.Size = new System.Drawing.Size(361, 63);
            this.lstCos.TabIndex = 0;
            // 
            // btnBack
            // 
            this.btnBack.Dock = System.Windows.Forms.DockStyle.Left;
            this.btnBack.FlatAppearance.BorderSize = 0;
            this.btnBack.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnBack.Font = new System.Drawing.Font("Segoe UI", 27.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnBack.Location = new System.Drawing.Point(0, 0);
            this.btnBack.Name = "btnBack";
            this.btnBack.Size = new System.Drawing.Size(71, 63);
            this.btnBack.TabIndex = 2;
            this.btnBack.Text = "<-";
            this.btnBack.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            this.btnBack.UseVisualStyleBackColor = true;
            this.btnBack.Visible = false;
            this.btnBack.Click += new System.EventHandler(this.btnBack_Click);
            // 
            // lblValCos
            // 
            this.lblValCos.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.lblValCos.AutoSize = true;
            this.lblValCos.Font = new System.Drawing.Font("Lucida Console", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblValCos.Location = new System.Drawing.Point(761, 33);
            this.lblValCos.Name = "lblValCos";
            this.lblValCos.Size = new System.Drawing.Size(140, 27);
            this.lblValCos.TabIndex = 1;
            this.lblValCos.Text = "0.00 Ron";
            this.lblValCos.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            // 
            // btnCos
            // 
            this.btnCos.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.btnCos.BackgroundImage = global::Magazin.ResourcesSmartphone.Cos;
            this.btnCos.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.btnCos.Dock = System.Windows.Forms.DockStyle.Right;
            this.btnCos.FlatAppearance.BorderSize = 0;
            this.btnCos.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnCos.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.btnCos.ForeColor = System.Drawing.Color.White;
            this.btnCos.Location = new System.Drawing.Point(907, 0);
            this.btnCos.MaximumSize = new System.Drawing.Size(58, 63);
            this.btnCos.Name = "btnCos";
            this.btnCos.Size = new System.Drawing.Size(58, 63);
            this.btnCos.TabIndex = 0;
            this.btnCos.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnCos.UseVisualStyleBackColor = true;
            this.btnCos.Click += new System.EventHandler(this.btnCos_Click);
            // 
            // frmMain
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoScroll = true;
            this.AutoScrollMargin = new System.Drawing.Size(10, 10);
            this.ClientSize = new System.Drawing.Size(965, 786);
            this.Controls.Add(this.pnlMain);
            this.Controls.Add(this.pnlTopBar);
            this.DoubleBuffered = true;
            this.Name = "frmMain";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "DejMag";
            this.pnlMain.ResumeLayout(false);
            this.tblTelefoane.ResumeLayout(false);
            this.panel11.ResumeLayout(false);
            this.panel10.ResumeLayout(false);
            this.panel9.ResumeLayout(false);
            this.panel8.ResumeLayout(false);
            this.panel7.ResumeLayout(false);
            this.panel6.ResumeLayout(false);
            this.panel5.ResumeLayout(false);
            this.panel4.ResumeLayout(false);
            this.panel3.ResumeLayout(false);
            this.panel2.ResumeLayout(false);
            this.panel1.ResumeLayout(false);
            this.pnlElementTelefoane.ResumeLayout(false);
            this.tblOferta.ResumeLayout(false);
            this.pnlOferta.ResumeLayout(false);
            this.pnlTopBar.ResumeLayout(false);
            this.pnlTopBar.PerformLayout();
            this.pnlCos.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion
        private System.Windows.Forms.Panel pnlMain;
        private System.Windows.Forms.Panel pnlTopBar;
        private System.Windows.Forms.TableLayoutPanel tblOferta;
        private System.Windows.Forms.Button btnCos;
        private System.Windows.Forms.Button btnTelevizor2;
        private System.Windows.Forms.Panel pnlOferta;
        private System.Windows.Forms.Button btnSmartphone2;
        private System.Windows.Forms.Button btnWearables2;
        private System.Windows.Forms.Button btnFoto2;
        private System.Windows.Forms.Button btnConsole2;
        private System.Windows.Forms.Button btnAudio2;
        private System.Windows.Forms.Button btnElectrocasnice2;
        private System.Windows.Forms.Button btnLaptop2;
        private System.Windows.Forms.Button btnDesktop2;
        private System.Windows.Forms.Label lblValCos;
        private System.Windows.Forms.TableLayoutPanel tblTelefoane;
        private System.Windows.Forms.Panel panel11;
        private System.Windows.Forms.Button button21;
        private System.Windows.Forms.Button button22;
        private System.Windows.Forms.Panel panel10;
        private System.Windows.Forms.Button button19;
        private System.Windows.Forms.Button button20;
        private System.Windows.Forms.Panel panel9;
        private System.Windows.Forms.Button button17;
        private System.Windows.Forms.Button button18;
        private System.Windows.Forms.Panel panel8;
        private System.Windows.Forms.Button button15;
        private System.Windows.Forms.Button button16;
        private System.Windows.Forms.Panel panel7;
        private System.Windows.Forms.Button button13;
        private System.Windows.Forms.Button button14;
        private System.Windows.Forms.Panel panel6;
        private System.Windows.Forms.Button button11;
        private System.Windows.Forms.Button button12;
        private System.Windows.Forms.Panel panel5;
        private System.Windows.Forms.Button button9;
        private System.Windows.Forms.Button button10;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.Button button7;
        private System.Windows.Forms.Button button8;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Button button5;
        private System.Windows.Forms.Button button6;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Panel pnlElementTelefoane;
        private System.Windows.Forms.Button btnPagElem1;
        private System.Windows.Forms.Button btnCosTel1;
        private System.Windows.Forms.Button btnBack;
        private System.Windows.Forms.Panel pnlCos;
        private System.Windows.Forms.ListBox lstCos;
        private System.Windows.Forms.Button btnComanda;
        private System.Windows.Forms.Button btnStergElem;
        private System.Windows.Forms.Button btnGolCos;
        private System.Windows.Forms.ListBox lstPreturi;
    }
}

